import { get,post } from '../http/api'
// 获取图书列表
export const getList = async (params) => {
  return post('/list',params)
}

export const listSuper = async (params) => {
  return post('/listSuper',params)
}

// save soldier
export const saveSoldier = async (params) => {
  return post('/saveSoldier',params)
}

// update soldier
export const updateSoldier = async (params) => {
  return post('/updateSoldier',params)
}

// remove soldier
export const removeSoldier = async (params) => {
  return post('/removeSoldier',params)
}
export const getChildrenList = async (params) => {
  return post('/getChildrenList',params)
}


