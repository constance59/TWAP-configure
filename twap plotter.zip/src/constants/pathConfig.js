export const url = {
  strategy: '/strategy/index',
  feature: '/feature/index',
  data: '/data/index',
  baseinsight: '/insight/baseinsight/index',
  competitive: '/competitive/index',
};

export const pathConfig = {
  url,
};
