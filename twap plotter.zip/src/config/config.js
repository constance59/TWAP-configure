import defaultSettings from './defaultSettings';

let prefix = "http://127.0.0.1:3000"
export default {
  prefix:prefix
};
