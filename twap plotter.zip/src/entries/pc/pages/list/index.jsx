import React, { Component } from 'react';
import react from 'react';
import ReactDOM from 'react-dom';
// import logo from './logo.svg';
import './index.scss';
import Plot from 'react-plotly.js'
// import axios from 'axios';
// import { plot } from 'plotly.js';

class MyForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      TotalQty: '',
      xvalues: [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75],
      Duration: 5,
      UpperFixedPctOffset: '',
      LowerFixedPctOffset: '',
      UpperLeewayPctOffset: '',
      LowerLeewayPctOffset: '',
      StartBoundTaperPct: '',
      EndBoundTaperPct: '',
      ProximityThresholdToTake: '',
      TakerTargetProximity: '',
      Urgency: '',
      data: []
    };
  }
  myChangeHandler = (event) => {
    let nam = event.target.name;
    let val = event.target.value;
    this.setState({ [nam]: val });
  }

  mySubmitHandler = (event) => {

    const { Duration, xvalues } = this.state;
    let targetFillData = [];
    let upperFixedFillBoundData = [];
    let lowerFixedFillBoundData = [];

    for (var i = 0; i < xvalues.length; i++) {
      let percentShares = (i * 1.0 / this.state.Duration);
      let scaleFactor = Math.pow(percentShares, this.state.Urgency);
      let targetFill = scaleFactor * this.state.TotalQty;
      let lowerFixedFillBound = targetFill - this.state.TotalQty * this.state.LowerFixedPctOffset;
      lowerFixedFillBound = lowerFixedFillBound < 0 ? 0 : lowerFixedFillBound;
      let upperFixedFillBound = targetFill + this.state.TotalQty * this.state.UpperFixedPctOffset;
      let lowerLeewayFillBound = (targetFill - targetFill * this.state.LowerLeewayPctOffset);
      lowerLeewayFillBound = lowerLeewayFillBound < 0 ? 0 : lowerLeewayFillBound;
      let upperLeewayFillBound = (targetFill + targetFill * this.state.UpperLeewayPctOffset);
      let upperFillBound = Math.min(upperLeewayFillBound, upperFixedFillBound);
      let lowerFillBound = Math.max(lowerLeewayFillBound, lowerFixedFillBound);
      let progress = targetFill / this.state.TotalQty;
      if (progress > this.state.EndBoundTaperPct) {
        upperFillBound = targetFill;
        lowerFillBound = targetFill;
      } else if (progress > this.state.StartBoundTaperPct) {
        let taperPct = (progress - this.state.StartBoundTaperPct) / (this.state.EndBoundTaperPct - this.state.StartBoundTaperPct);
        let upperTaperAdjust = (upperFillBound - targetFill) * taperPct;
        upperFillBound = upperFillBound - upperTaperAdjust;
        let lowerTaperAdjust = (targetFill - lowerFillBound) * taperPct;
        lowerFillBound = lowerFillBound + lowerTaperAdjust;
      }

      event.preventDefault();

      targetFillData.push(targetFill)
      upperFixedFillBoundData.push(upperFixedFillBound)
      lowerFixedFillBoundData.push(lowerFixedFillBound)

    }

    let targetFillChartData = {
      x: xvalues,
      y: targetFillData,
      mode: 'lines',
      marker: { color: 'black' },
      name: "TargerFillQty"
    }

    let upperFixedFillChartData = {
      x: xvalues,
      y: upperFixedFillBoundData,
      mode: 'lines',
      marker: { color: 'red' },
      name: "UpperFillQtyBound"
    }

    let lowerFixedFillBoundChartData = {
      x: xvalues,
      y: lowerFixedFillBoundData,
      mode: 'lines',
      marker: { color: 'blue' },
      name: "LowerFillQtyBound"
    }
    console.log('values', lowerFixedFillBoundChartData);


    this.setState({
      data: [
        targetFillChartData,
        upperFixedFillChartData,
        lowerFixedFillBoundChartData
      ]
    })

  }

  //handle input//

  TotalQtyHandler = event => {
    this.setState({ TotalQty: event.target.value })
  }

  DurationHandler = event => {
    this.setState({ Duration: event.target.value })
  }

  UpperFixedPctOffsetHandler = event => {
    this.setState({ UpperFixedPctOffset: event.target.value })
  }

  LowerFixedPctOffsetHandler = event => {
    this.setState({ LowerFixedPctOffset: event.target.value })
  }

  UpperLeewayPctOffsetHandler = event => {
    this.setState({ UpperLeewayPctOffset: event.target.value })
  }

  LowerLeewayPctOffsetHandler = event => {
    this.setState({ LowerLeewayPctOffset: event.target.value })
  }

  StartBoundTaperPctHandler = event => {
    this.setState({ StartBoundTaperPct: event.target.value })
  }

  EndBoundTaperPctHandler = event => {
    this.setState({ EndBoundTaperPct: event.target.value })
  }

  ProximityThresholdToTakeHandler = event => {
    this.setState({ ProximityThresholdToTake: event.target.value })
  }

  TakerTargetProximityHandler = event => {
    this.setState({ TakerTargetProximity: event.target.value })
  }

  UrgencyHandler = event => {
    this.setState({ Urgency: event.target.value })
  }

  //form//
  render() {
    const { data } = this.state
    return (
      <div style={{ padding: 20 }}>
        <div>
          <form onSubmit={this.mySubmitHandler}>
            <h1>TWAP Plotter</h1>
            <div className="row">
              {/*TotalQty*/}
              <label className='control-label' col-sm-2 for='TotalQty'>TotalQty: </label>
              <input
                type='number'
                name='TotalQty'
                className='form=control'
                onChange={this.myChangeHandler}
              />

              {/*Duration (in mintues)*/}
              <label className='control-label' col-sm-2 for='Duration'>Duration (in mintues): </label>
              <input
                type='number'
                name='Duration'
                onChange={this.myChangeHandler}
              />
            </div>
            <div className="row">
              {/*UpperFixedPctOffset(%)*/}
              <label className='control-label' col-sm-2 for='UpperFixedPctOffset'>UpperFixedPctOffset(%): </label>
              <input
                type='number'
                name='UpperFixedPctOffset'
                onChange={this.myChangeHandler}
              />

              {/*LowerFixedPctOffset(%)*/}
              <label className='control-label' col-sm-2 for='LowerFixedPctOffset'>LowerFixedPctOffset(%): </label>
              <input
                type='number'
                name='LowerFixedPctOffset'
                onChange={this.myChangeHandler}
              />
            </div>
            <div className="row">
              {/*UpperLeewayPctOffset(%)*/}
              <label className='control-label' col-sm-2 for='UpperLeewayPctOffset'>UpperLeewayPctOffset(%): </label>
              <input
                type='number'
                name='UpperLeewayPctOffset'
                onChange={this.myChangeHandler}
              />

              {/*LowerLeewayPctOffset(%)*/}
              <label className='control-label' col-sm-2 for='LowerLeewayPctOffset'>LowerLeewayPctOffset(%): </label>
              <input
                type='number'
                name='LowerLeewayPctOffset'
                onChange={this.myChangeHandler}
              />
            </div>
            <div className="row">
              {/*StartBoundTaperPct(%)*/}
              <label className='control-label' col-sm-2 for='StartBoundTaperPct'>StartBoundTaperPct(%): </label>
              <input
                type='number'
                name='StartBoundTaperPct'
                onChange={this.myChangeHandler}
              />

              {/*EndBoundTaperPct(%)*/}
              <label className='control-label' col-sm-2 for='EndBoundTaperPct'>EndBoundTaperPct(%): </label>
              <input
                type='number'
                name='EndBoundTaperPct'
                onChange={this.myChangeHandler}
              />
            </div>
            <div className="row">
              {/*ProximityThresholdToTake*/}
              <label className='control-label' col-sm-2 for='ProximityThresholdToTake'>ProximityThresholdToTake: </label>
              <input
                type='number'
                name='ProximityThresholdToTake'
                onChange={this.myChangeHandler}
              />

              {/*TakerTargetProximity*/}
              <label className='control-label' col-sm-2 for='TakerTargetProximity'>TakerTargetProximity: </label>
              <input
                type='number'
                name='TakerTargetProximity'
                onChange={this.myChangeHandler}
              />
            </div>
            <div className="row">
              {/*Urgency*/}
              <label className='control-label' col-sm-2 for='Urgency'>Urgency: </label>
              <input
                type='number'
                name='Urgency'
                onChange={this.myChangeHandler}
              />
              <input className="submit-button"
                type='submit'
                value="submit"
              >
              </input>
            </div>
          </form>
        </div>
        <div>
          <Plot
            data={data}
            layout={{ width: 1000, height: 240, title: 'A Fancy Plot' }}
          />
        </div>
      </div>
    );
  }
}

export default MyForm;