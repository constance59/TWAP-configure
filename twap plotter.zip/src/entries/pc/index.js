import React from 'react';
import { HashRouter, Route } from 'react-router-dom';
import { Switch } from 'react-router';
import BasicLayout from './layout/BasicLayout'
import List from './pages/list'


function App() {
  return (
    <HashRouter>
      <Switch>
        <BasicLayout>
          <Route path="/" component={List} />
        </BasicLayout>
      </Switch>
    </HashRouter>
  );
}

export default App;
