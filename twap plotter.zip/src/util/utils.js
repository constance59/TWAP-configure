import moment from 'moment';
import { Modal, Toast } from 'antd-mobile';

const { alert } = Modal;

/**
 * 路由跳转
 * @param {object} params
 */
export function routerChange(url) {
  //history.push(url);
}

/**
 * 回到顶部
 * @param {object} params
 */
export function backToTop() {
  window.scrollTo({
    left: 0,
    top: 0,
    behavior: 'smooth',
  });
}

/**
 * 获取星期中文
 * @param {object} params
 */
export function getWeekDayZh(num) {
  let title = '';
  switch (num) {
    case 0:
      title = '周一';
      break;
    case 1:
      title = '周二';
      break;
    case 2:
      title = '周三';
      break;
    case 3:
      title = '周四';
      break;
    case 4:
      title = '周五';
      break;
    case 5:
      title = '周六';
      break;
    case 6:
      title = '周日';
      break;
    default:
      title = '周一';
      break;
  }
  return title;
}

/**
 * 获取星期中文
 * @param {object} params
 */
export function getTimeTitle(num) {
  let title = '';
  switch (num) {
    case 0:
      title = '';
      break;
    case 1:
      title = '早餐';
      break;
    case 2:
      title = '午餐';
      break;
    case 3:
      title = '下午茶';
      break;
    case 4:
      title = '晚餐';
      break;
    case 5:
      title = '夜宵';
      break;
    default:
      title = '';
      break;
  }
  return title;
}

// 转换成日期标题
export function castDateTitle(days) {
  const weeks = days.map(day => {
    const d = moment(day);
    return d.weekday();
  })
  const continueDays = [];
  let last = weeks[0];
  let newContinueDays = [];
  continueDays.push(newContinueDays);
  for (let i = 0; i < weeks.length; i++) {
    const v = weeks[i];
    if (last + 1 !== v) {
      newContinueDays = [];
      continueDays.push(newContinueDays);
    }

    newContinueDays.push({ w: v, d: days[i] });
    last = v;
  }

  const weekStrs = continueDays.filter(item => item.length > 0).map(item => {
    const start = item[0];
    if (item.length >= 2) {
      const end = item[item.length - 1];
      return `${getWeekDayZh(start.w)}~${getWeekDayZh(end.w)}`;
    }
      return `${getWeekDayZh(start.w)}`;
  }).join(',');

  const dates = continueDays.filter(item => item.length > 0).map(item => {
    const start = item[0];
    if (item.length >= 2) {
      const end = item[item.length - 1];
      return `${moment(start.d).format('YYYY-MM-DD')}~${moment(end.d).format('YYYY-MM-DD')}`;
    }
      return `${moment(start.d).format('YYYY-MM-DD')}`;
  }).join(',');

  return { weeks: weekStrs, dates };
}

// 生成倒计时
export function createCountdown(endMoment) {
  const m1 = moment(new Date())
  const ms = endMoment - m1;


  if (ms < 0) {
    return '';
  }
  const du = moment.duration(ms, 'ms');
  const mins = du.get('minutes');
  const ss = du.get('seconds');
  const countdown = `${prefixInteger(mins, 2)}分${prefixInteger(ss, 2)}秒`

  return countdown;
}

export function prefixInteger(num, n) {
   return (Array(n).join(0) + num).slice(-n)
}


// eslint-disable-next-line func-names
window.Date.prototype.format = function (fmt) {
  let time = fmt;
  const o = {
    'M+': this.getMonth() + 1,
    'd+': this.getDate(),
    'h+': this.getHours(),
    'm+': this.getMinutes(),
    's+': this.getSeconds(),
    'q+': Math.floor((this.getMonth() + 3) / 3),
  };
  if (/(y+)/.test(time)) {
    time = time.replace(RegExp.$1, `${this.getFullYear()}`.substr(4 - RegExp.$1.length));
  }
  const key = Object.keys(o);
  //   const val = Object.values(o);
  const len = key.length;
  //   for (const k in o) {
  for (let i = 0; i < len; i += 1) {
    if (new RegExp(`(${key[i]})`).test(time)) {
      time = time.replace(
        RegExp.$1,
        RegExp.$1.length === 1 ? o[key[i]] : `00${o[key[i]]}`.substr(`${o[key[i]]}`.length),
      );
    }
  }
  return time;
};

export function fen2yuan(num) {
  return num && !isNaN(num) ? parseFloat((num / 100).toPrecision(12)) : 0;
}

export function yuan2fen(num) {
  return num && !isNaN(num) ? parseFloat((num * 100).toPrecision(12)) : 0;
}

// 判断安卓
export function isAndroid() {
  var u = navigator.userAgent;
  if (u.indexOf("Android") > -1) {
    return true;
  }
  return false;
}
// 判断设备为 ios
export function isIos() {
  var u = navigator.userAgent;
  if (u.indexOf("iPhone") > -1 || u.indexOf("iOS") > -1) {
      return true;
  }
  return false;
}
export function isInWeixin(){  
  var ua = navigator.userAgent.toLowerCase();  
  if(ua.match(/MicroMessenger/i)=="micromessenger") {  
      return true;  
  } else {  
      return false;  
  }  
}