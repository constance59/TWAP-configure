import { Sdk } from '@ali/ele-fos';

/**
 * 前端获取请求参数
 * @param {string} url 链接，默认值是 `window.location.href`
 * @returns {object}
 */
export function getQueryObject(url = window.location.href) {
  const search = url
    .split('#')[0]
    .split('?')
    .slice(1)
    .join('');
  if (!search) {
    return {};
  }
  return search.split('&').reduce((res, pair) => {
    const [name, value] = pair.split('=');
    res[name] = decodeURIComponent(value || '');
    return res;
  }, {});
}

/**
 * 前端获取请求参数
 * @param {string} url 链接，默认值是 `window.location.href`
 * @returns {object}
 */
export function getAllUrlParams(url = window.location.href) {
  const isSpecialKey = RegExp.prototype.test.bind(/^(?:toString|valueOf)$/);
  const obj = {};
  url.replace(/([^=?#&]*)=([^?#&]*)/g, (e, $1, $2) => {
    if (!isSpecialKey($1)) obj[decodeURIComponent($1)] = decodeURIComponent($2);
  });
  return obj;
}

/**
 * json对象转querystring
 * @param {object} params
 */
export function toQuery(params) {
  return Object.entries(params)
    .map(([name, value]) => `${name}=${encodeURIComponent(value)}`)
    .join('&');
}

/**
 * 添加查询参数
 *
 * ```javascript
 * addQuery(window.location.href, {a: 1})
 * ```
 *
 * @param url
 * @param {object} params
 * @returns {string}
 */
export function addQuery(url, params) {
  const query = toQuery(Object.assign(getQueryObject(url), params));
  const [base, hash] = url.split('#');
  // eslint-disable-next-line no-unused-vars
  const [path] = base.split('?');
  return `${path}?${query}${hash ? '#' : ''}${hash || ''}`;
}

/**
 * 获取cookie数据
 * @param name
 * @returns {string | string}
 */
export const getCookie = name => {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) {
    return (
      parts
        .pop()
        .split(';')
        .shift() || ''
    );
  }
};

export const QUERY_STRING = (() => window.location.search.slice(1))();
export const QUERY = (() => getQueryObject(window.location.href))();

export function getQueryParam(name) {
  return QUERY[name];
}

/**
 * 设置Tab栏的显示隐藏
 * @param {object} params
 */
export function setTab(flag) {
  const sdk = new Sdk();
  sdk.invoke({
    service: 'OS',
    method: 'setTab',
    payload: {
      open: flag,
    },
  });
}

/**
 * 获取tab栏高度
 * @param {object} params
 */
export function getTabHeight() {
  const sdk = new Sdk();
  let tabHeight;
  sdk
    .invoke({
      service: 'OS',
      method: 'getTabHeight',
      payload: {},
    })
    .then(res => {
      tabHeight = res;
    });
  return tabHeight || 0;
}

/**
 * 设置高度
 * @param {object} params
 */
export function setHeight(height) {
  const sdk = new Sdk();
  sdk.invoke({
    service: 'OS',
    method: 'setHeight',
    payload: {
      height,
    },
  });
}

/**
 * 获取窗口高度
 * @param {object} params
 */
export function getWindowHeight() {
  const sdk = new Sdk();
  let windowHeight;
  sdk
    .invoke({
      service: 'OS',
      method: 'getWindowHeight',
      payload: {},
    })
    .then(res => {
      windowHeight = res;
    });
  return windowHeight;
}

/**
 * 跳转
 * @param {object} params
 */
export function jumpTo(url) {
  const sdk = new Sdk();
  sdk.invoke({
    service: 'OS',
    method: 'jumpTo',
    payload: {
      url,
    },
  });
}

/**
 * 跳转
 * @param {object} params
 */
export function formatDate(date) {
  const d = new Date(date);
  return `${d.getFullYear()}-${d.getMonth() +
    1}-${d.getDate()} ${d.getHours()}:${d.getMinutes()}${d.getSeconds()}`;
}
