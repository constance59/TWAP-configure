# 发布
sudo scp -r ./build/*  root@139.196.40.161:/root/smartfrontend/h5_majiang_zxw_static
